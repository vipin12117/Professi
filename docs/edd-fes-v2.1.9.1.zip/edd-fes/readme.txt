﻿/**
 * Plugin Name:         Easy Digital Downloads - Frontend Submissions
 * Plugin URI:          https://easydigitaldownloads.com/extension/frontend-submissions/
 * Description:         Allow vendors to submit products
 * Author:              Chris Christoff
 * Author URI:          http://www.chriscct7.com
 *
 * @category            Plugin
 * @copyright           Copyright © 2013 Chris Christoff
 * @author              Chris Christoff
 * @package             FES
 */

Mimick eBay, Envato, or Amazon type sites with this plugin and Easy Digital Downloads combined!

Want to allow other users to sell products on your site? Now you can!

Documentation:
kb.eddfes.com