<?php
echo do_shortcode('[edd_fes_combo_form]');