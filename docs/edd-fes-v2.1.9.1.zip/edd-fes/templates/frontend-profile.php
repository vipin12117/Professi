<?php
echo do_shortcode('[fes_profile]');