jQuery(document).ready(function() {
	jQuery(".sf-tips").tooltip({ animation: true, html: true, delay: { show: 300, hide: 100 } });
});