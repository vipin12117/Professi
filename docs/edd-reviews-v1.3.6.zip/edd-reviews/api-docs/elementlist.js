
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","EDD_License"],["f","edd_license_key_callback()"],["c","EDD_Reviews"],["f","edd_reviews()"],["f","edd_reviews_callback()"],["c","EDD_Reviews_Shortcode_Review"],["c","EDD_Reviews_Widget_Featured_Review"],["c","EDD_Reviews_Widget_Reviews"],["c","EDD_SL_Plugin_Updater"]];
