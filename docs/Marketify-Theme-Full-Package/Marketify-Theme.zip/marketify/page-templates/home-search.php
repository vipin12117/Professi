<?php
/**
 * Template Name: Homepage (with Search)
 */

locate_template( array( 'page-templates/home.php' ), true );