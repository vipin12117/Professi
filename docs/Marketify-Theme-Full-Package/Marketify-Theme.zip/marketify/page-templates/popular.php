<?php
/**
 * Template Name: Popular Items
 *
 * @package Marketify
 */

return locate_template( array( 'page-templates/shop.php' ), true );