<?php
/**
 * Download Category
 */

locate_template( array( 'archive-download.php' ), true );