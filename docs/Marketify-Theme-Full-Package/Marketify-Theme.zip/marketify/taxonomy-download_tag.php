<?php
/**
 * Download Tag
 */

locate_template( array( 'archive-download.php' ), true );