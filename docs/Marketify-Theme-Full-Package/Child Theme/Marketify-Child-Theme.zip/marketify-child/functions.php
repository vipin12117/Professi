<?php
/**
 * Marketify Child Theme
 *
 * Place any custom functionality/code snippets here.
 *
 * @since Marketify Child 1.0
 */